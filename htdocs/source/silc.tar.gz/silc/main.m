//
//  main.m
//  SILC Aqua
//
//  Created by Matthew Hielscher on 12/28/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
