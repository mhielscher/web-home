package EigenMeat.EigenMaze;

/**
 * Entry point of game.
 */
public class EigenMaze {
  public static void main(String args[]) {
    Game eigenMeat = new Game("Eigen Maze v?.?.?");
  }
}
