package EigenMeat.EigenMaze;

/**
 * Allows an object to insert itself into the game control loop. Seems deprecated.
 */
interface Processable {
	public void process();
}
