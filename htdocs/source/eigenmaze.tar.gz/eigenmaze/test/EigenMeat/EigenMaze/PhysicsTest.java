package EigenMeat.EigenMaze;

import junit.framework.*;

public class PhysicsTest extends TestCase {
	public PhysicsTest() {
		super();
	}
	
	public PhysicsTest(String name) {
		super(name);
	}
	
	public void testCheckSphereCollision() {
		/*
		Vect3d a = new Vect3d(0,0,0);
		Vect3d b = new Vect3d(5,0,0);
		assertFalse(Physics.checkSphereCollision(a, 2, b, 2));
		assertTrue(Physics.checkSphereCollision(a, 3, b, 3));
		b.set(3,0,0);
		assertTrue(Physics.checkSphereCollision(a, 2, b, 2));
		*/
	}
}