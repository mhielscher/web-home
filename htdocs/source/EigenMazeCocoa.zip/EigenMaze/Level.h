//
//  Level.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Octree.h"
#import "Frustum.h"
#import "Drawable.h"

@interface Level : NSObject <Drawable> {
	Octree *staticLevel;
}

- (id)init;

- (void)drawGL;
- (void)drawGLWithFrustum:(Frustum*)frustum;

- (void)dealloc;

@end
