//
//  Triangle.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/3/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "Vect3d.h"
#import "Texture.h"
#import "Drawable.h"

//sphere collision-checking positions
enum SpherePosition {
	FRONT,
	BACK,
	INTERSECT
};

//types of collisions
enum CollisionType {
	NONE,
	DIRECT,
	EDGE
};

typedef struct {
	float r;
	float g;
	float b;
} EigenColor;

EigenColor WHITE = {1.0f, 1.0f, 1.0f};
EigenColor BLACK = {0.0f, 0.0f, 0.0f};
EigenColor RED = {1.0f, 0.0f, 0.0f};
EigenColor GREEN = {0.0f, 1.0f, 0.0f};
EigenColor BLUE = {0.0f, 0.0f, 1.0f};
EigenColor BEIGE = {0.9f, 0.85f, 0.75f};

@interface Triangle : NSObject <Drawable> {
	NSMutableArray *vertices;
	NSMutableArray *uvPoints;
	EigenColor color;
	Texture *texture;
	Vect3d *normal;
	
	NSMutableDictionary *neighbors;
	
	BOOL visible;
	
	//cached values for collision detection speed
	float planeDistance;
	float possibleEdgeCollision;
	
	float collisionPoint;
	Vect3d *realCollisionPoint;
	
	BOOL lightmapEnabled;
	//Lightmap *lightmap;
	NSMutableArray *uvLightmap;
	
	int renderFrame;
	BOOL renderOnce;
}

-(id)init;
-(id)initWithVertices:(NSArray*)vert color:(EigenColor)c;
-(id)initWithVertices:(NSArray*)vert uv:(NSArray*)uv color:(EigenColor)c texture:(Texture*)tex;

+(void)calculateTriangleNeighbors:(NSArray*)triangles;

-(Vect3d*)getNormal;
-(void)setNormal:(Vect3d*)v;
-(Vect3d*)getVertexNumber:(int)num;
-(void)setVertexNumber:(int)num vector:(Vect3d*)v;
-(NSPoint)getUVNumber:(int)num;
-(EigenColor)getColor;
-(void)setColor:(EigenColor)c;
-(Texture*)getTexture;
-(void)setTexture:(Texture*)tex;
-(void)setRenderOnce:(BOOL)b;
-(BOOL)hasLightmap;
-(void)setNeighbor:(Triangle*)neighbor edge:(int)edge;
-(BOOL)hasNeighborAtEdge:(int)edge;
-(Triangle*)getNeighborAtEdge:(int)edge;
-(void)setVisible:(BOOL)b;
-(BOOL)isVisible;
-(void)calculateNormal;
-(float)getPlaneDistance;
-(void)createLightmap;

//collision detection
-(enum SpherePosition)classifySphereWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel;
-(float)getDistanceFromPlaneToPoint:(Vect3d*)point;
-(BOOL)pointInFront:(Vect3d*)point;
-(BOOL)pointInTriangle:(Vect3d*)point;
-(BOOL)planeIntersectedByLineFrom:(Vect3d*)p1 to:(Vect3d*)p2;
-(BOOL)collisionPointInTriWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel;
-(float)getMostRecentCollisionPoint;
-(enum CollisionType)checkSphereCollisionWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel;
-(Vect3d*)getRealCollisionPoint;
-(BOOL)checkEdgeCollisionWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel;
-(BOOL)edgeContainsPoint:(Vect3d*)p;

-(BOOL)isEqualTo:(id)object;
-(NSComparisonResult)compareTo:(id)object;

-(void)drawGL;
-(void)drawGLPlain;
-(void)drawGLTextured;
-(void)drawGLMultitexture;
-(void)drawGLRaw;

-(void)dealloc;

@end
