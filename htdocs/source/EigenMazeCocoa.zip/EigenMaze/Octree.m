//
//  Octree.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Octree.h"


@implementation Octree

- (id)init
{
	triangles = [[NSMutableArray alloc] init];
	center = [[Vect3d alloc] init];
	width = 0;
	
	root = nil;
	
	return self;
}

- (id)initWithTriangles:(NSArray*)tri
{
	triangles = [[NSMutableArray alloc] initWithArray:tri];
	center = [[Vect3d alloc] init];
	width = [self determineWidth];
	
	root = [[OctreeNode alloc] initWithTriangles:triangles center:center];
	
	return self;
}

- (float)determineWidth
{
	if (root)
		return [root determineWidth];
	else
		return 0;
}

- (void)drawGL
{
	if (root)
		[root drawGL];
}

- (void)drawGLWithFrustum:(Frustum*)frustum
{
	if (root)
		[root drawGLWithFrustum:frustum];
}

- (void)dealloc
{
	[triangles release];
	[center release];
	[root release];
	[super dealloc];
}

@end
