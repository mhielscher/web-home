//
//  Entity.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Entity.h"
#import "Constants.h"

@implementation Entity

- (id)init
{
	mesh = nil;
	position = [[Vect3d alloc] initWithX:0 Y:0 Z:0];
	velocity = [[Vect3d alloc] initWithX:0 Y:0 Z:0];
	forwardVect = [[Vect3d alloc] initWithX:1 Y:0 Z:0];
	rotation = [[Vect3d alloc] initWithX:0 Y:0 Z:0];
	boundingRadius = 0;
	return self;
}

- (void)setPosition:(Vect3d*)v
{
	if (v)
	{
		[v retain];
		[position release];
		position = v;
	}
}

- (void)setVelocity:(Vect3d*)v
{
	if (v)
	{
		[v retain];
		[velocity release];
		velocity = v;
	}
}

- (void)setMesh:(Mesh*)m
{
	if (m)
		[m retain];
	if (mesh)
		[mesh release];
	mesh = m;
}

- (void)setRotY:(float)y
{
	[rotation setY:y];
	[forwardVect setToX:0 Y:0 Z:-1];
	[forwardVect rotateY:y];
}

- (void)setRotZ:(float)z
{
	[rotation setZ:z];
}

- (Vect3d*)getForwardVect
{
	return forwardVect;
}

- (Vect3d*)getPosition
{
	return position;
}

- (void)setBoundingRadius:(float)r
{
	if (r >= 0)
		boundingRadius = r;
}

- (void)drawGL
{
	if (mesh)
	{
		glPushMatrix();
		glTranslatef([position getX], [position getY], [position getZ]);
		
		[mesh drawGL];
		[self update];
		
		glPopMatrix();
	}
}

- (void)update
{
	[position autorelease];
	position = [[position addWith:[velocity multiplyWith:DEFAULT_TIME_INTERVAL]] retain];
	//NSLog(@"Position is %f, %f, %f", [position getX], [position getY], [position getZ]);
}

- (void)dealloc
{
	if (mesh)
		[mesh release];
	[position release];
	[velocity release];
	[forwardVect release];
	[rotation release];
	[super dealloc];
}

@end
