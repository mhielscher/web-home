//
//  Frustum.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Frustum.h"


@implementation Frustum

- (id)init
{
	for (int i=0; i<6; i++)
		frustum[i] = [[Plane alloc] init];
	return self;
}

- (void) calculate
{
	float model[16];
	float projection[16];
	float clip[16];
	
	glGetFloatv(GL_PROJECTION_MATRIX,projection);
	glGetFloatv(GL_MODELVIEW_MATRIX,model);

	clip[0] = model[0]*projection[0] + model[1]*projection[4] + model[2]*projection[8] + model[3]*projection[12];
	clip[1] = model[0]*projection[1] + model[1]*projection[5] + model[2]*projection[9] + model[3]*projection[13];
	clip[2] = model[0]*projection[2] + model[1]*projection[6] + model[2]*projection[10] + model[3]*projection[14];
	clip[3] = model[0]*projection[3] + model[1]*projection[7] + model[2]*projection[11] + model[3]*projection[15];
	
	clip[4] = model[4]*projection[0] + model[5]*projection[4] + model[6]*projection[8] + model[7]*projection[12];
	clip[5] = model[4]*projection[1] + model[5]*projection[5] + model[6]*projection[9] + model[7]*projection[13];
	clip[6] = model[4]*projection[2] + model[5]*projection[6] + model[6]*projection[10] + model[7]*projection[14];
	clip[7] = model[4]*projection[3] + model[5]*projection[7] + model[6]*projection[11] + model[7]*projection[15];
	
	clip[8] = model[8]*projection[0] + model[9]*projection[4] + model[10]*projection[8] + model[11]*projection[12];
	clip[9] = model[8]*projection[1] + model[9]*projection[5] + model[10]*projection[9] + model[11]*projection[13];
	clip[10] = model[8]*projection[2] + model[9]*projection[6] + model[10]*projection[10] + model[11]*projection[14];
	clip[11] = model[8]*projection[3] + model[9]*projection[7] + model[10]*projection[11] + model[11]*projection[15];
	
	clip[12] = model[12]*projection[0] + model[13]*projection[4] + model[14]*projection[8] + model[15]*projection[12];
	clip[13] = model[12]*projection[1] + model[13]*projection[5] + model[14]*projection[9] + model[15]*projection[13];
	clip[14] = model[12]*projection[2] + model[13]*projection[6] + model[14]*projection[10] + model[15]*projection[14];
	clip[15] = model[12]*projection[3] + model[13]*projection[7] + model[14]*projection[11] + model[15]*projection[15];

	//right plane
	[frustum[0] setA:(clip[3]-clip[0]) B:(clip[7]-clip[4]) C:(clip[11]-clip[8]) D:(clip[15]-clip[12])];
	[frustum[0] normalize];

	//left plane
	[frustum[1] setA:(clip[3]+clip[0]) B:(clip[7]+clip[4]) C:(clip[11]+clip[8]) D:(clip[15]+clip[12])];
	[frustum[1] normalize];

	//bottom plane
	[frustum[2] setA:(clip[3]+clip[1]) B:(clip[7]+clip[5]) C:(clip[11]+clip[9]) D:(clip[15]+clip[13])];
	[frustum[2] normalize];

	//top plane
	[frustum[3] setA:(clip[3]-clip[1]) B:(clip[7]-clip[5]) C:(clip[11]-clip[9]) D:(clip[15]-clip[13])];
	[frustum[3] normalize];

	//far plane
	[frustum[4] setA:(clip[3]-clip[2]) B:(clip[7]-clip[6]) C:(clip[11]-clip[10]) D:(clip[15]-clip[14])];
	[frustum[4] normalize];

	//near plane
	[frustum[5] setA:(clip[3]+clip[2]) B:(clip[7]+clip[6]) C:(clip[11]+clip[10]) D:(clip[15]+clip[14])];
	[frustum[5] normalize];	
}

- (BOOL)isCubeInFrustum:(Vect3d*)center size:(float)size
{
	float sh = size/2;
	float x = [center getX];
	float y = [center getY];
	float z = [center getZ];
		
	for(int i=0; i<6; i++) {
		if(![frustum[i] isPointInFrontX:(x-sh) Y:(y-sh) Z:(z-sh)] &&
			![frustum[i] isPointInFrontX:(x+sh) Y:(y-sh) Z:(z-sh)] &&
			![frustum[i] isPointInFrontX:(x+sh) Y:(y+sh) Z:(z-sh)] &&
			![frustum[i] isPointInFrontX:(x-sh) Y:(y+sh) Z:(z-sh)] &&
			![frustum[i] isPointInFrontX:(x-sh) Y:(y-sh) Z:(z+sh)] &&
			![frustum[i] isPointInFrontX:(x+sh) Y:(y-sh) Z:(z+sh)] &&
			![frustum[i] isPointInFrontX:(x+sh) Y:(y+sh) Z:(z+sh)] &&
			![frustum[i] isPointInFrontX:(x-sh) Y:(y+sh) Z:(z+sh)])
			return NO;
	}

	return YES;
}

- (void)dealloc
{
	for (int i=0; i<6; i++)
		[frustum[i] release];
	[super dealloc];
}

@end
