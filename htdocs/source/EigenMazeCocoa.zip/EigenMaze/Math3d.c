/*
 *  Math3d.c
 *  EigenMaze
 *
 *  Created by Matthew Hielscher on 4/12/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "Math3d.h"

float getPlaneDistance(Vect3d *planeNormal, Vect3d *pointOnPlane)
{
	return -1.0f * [planeNormal dotWith:pointOnPlane];
}

float getPointDistanceFromPlane(Vect3d *planeNormal, float distance, Vect3d *point)
{
	return ([planeNormal dotWith:point] + distance);
}

BOOL isPointInFrontOfPlane(Vect3d *planeNormal, float distance, Vect3d *point)
{
	return ([planeNormal dotWith:point]+distance >= 0);
}

Vect3d *getCollisionPointWithPlane(Plane *plane, Vect3d *point, Vect3d *direction)
{
	return getCollisionPointWithPlaneDef([plane getNormal], [plane getPlaneDistance], point, direction);
}

Vect3d *getCollisionPointWithPlane(Vect3d *planeNormal, float distance, Vect3d *point, Vect3d direction)
{
	float n = -1 * getPointDistanceFromPlane(planeNormal, distance, distance, point);
	float d = [planeNormal dotWith:direction];
	
	if (d == 0)
		return [point copyWithZone:nil];
	
	float lineDistance = (n/d);
	return [[direction multiplyWith:lineDistance] addWith:point];
}

//uses Woo's Method - http://www.acm.org/tog/GraphicsGems/gems/RayBox.c
//cull away back-facing planes, find farthest plane intersection
//check that intersection to see if it's within the square
//don't believe me? farthest _non_culled_ plane is the best candidate - draw it in 2D

BOOL lineIntersectsAABCube(Vect3d *cen, float radius, Vect3d *p1, Vect3d *p2)
{
	/*
	Plane *cube[6];
	//doing it by hand because the mask method looked hackish
	cube[0] = [[Plane alloc] initWithNormal:[Vect3d unitVectorX] point:[cen addWith:[Vect3d vectorWithX:radius Y:0 Z:0]]];
	cube[1] = [[Plane alloc] initWithNormal:[Vect3d unitVectorY] point:[cen addWith:[Vect3d vectorWithX:0 Y:radius Z:0]]];
	cube[2] = [[Plane alloc] initWithNormal:[Vect3d unitVectorZ] point:[cen addWith:[Vect3d vectorWithX:0 Y:0 Z:radius]]];
	cube[3] = [[Plane alloc] initWithNormal:[[Vect3d unitVectorX] invert] point:[cen addWith:[Vect3d vectorWithX:-radius Y:0 Z:0]]];
	cube[4] = [[Plane alloc] initWithNormal:[[Vect3d unitVectorY] invert] point:[cen addWith:[Vect3d vectorWithX:0 Y:-radius Z:0]]];
	cube[5] = [[Plane alloc] initWithNormal:[[Vect3d unitVectorZ] invert] point:[cen addWith:[Vect3d vectorWithX:0 Y:0 Z:-radius]]];
	*/
	
	// I think I'll use the slightly obfuscated code from the Java version, from Woo's example.
	// The easy-to-read OOP-style code was looking bloated
	Vect3d *direction = [[p2 subtractBy:p1] normalize];
			
	//we convert our Vect3ds to float arrays to make it easier
	//to process them
	float center[] = {[cen getX], [cen getY], [cen getZ]};
	float min[] = {[cen getX], [cen getY], [cen getZ]};
	min[0]-=radius;
	min[1]-=radius;
	min[2]-=radius;
	float max[] = {[cen getX], [cen getY], [cen getZ]};
	max[0]+=radius;
	max[1]+=radius;
	max[2]+=radius;
	float point[] = {[p1 getX], [p1 getY], [p1 getZ]};
	float dir[] = {[direction getX], [direction getY], [direction getZ]};
	float checkPlane[3];
	checkPlane[0]=checkPlane[1]=checkPlane[2]=1000; //omg hack
	float maxt[3];
	maxt[0]=maxt[1]=maxt[2]=-1;

	//calculate possible planes line can intersect
	for(int i=0; i<3; i++) {
		if(point[i] < center[i]-radius)
				checkPlane[i] = center[i]-radius;
			else if(point[i] > center[i]+radius)
					checkPlane[i] = center[i]+radius;
	}

	//check to see if line origin is inside box
	//ugly ugly hack
	if(checkPlane[0] == 1000 && checkPlane[1] == 1000 && checkPlane[2] == 1000)
		return YES;

	//calculate distance to each plane it  
	for(int i=0; i<3; i++) {
		if(checkPlane[i] != 1000) {
				maxt[i] = (checkPlane[i]-point[i])/dir[i];
		}
	}

	//which plane has the furthest possible collision point
	//according to Woo, the plane furthest way is the plane
	//that the line can intersect
	int maxPlane = 0;
	if(maxt[0] > maxt[1] && maxt[0] > maxt[2])
		maxPlane = 0;
	if(maxt[1] > maxt[0] && maxt[1] > max[2])
		maxPlane = 1;
	if(maxt[2] > maxt[0] && maxt[2] > maxt[1])
		maxPlane = 2;

	//once we know which plane to check, calculate the collision
	//point and see if it is inside the cube face
	float cPoint[] = new float[3];
	for(int i=0; i<3; i++) {
		if(i != maxPlane) {
			cPoint[i] = point[i]+maxt[maxPlane]*dir[i];
			if(cPoint[i] < min[i] || cPoint[i] > max[i])
				return NO;
		} else {
			cPoint[i] = checkPlane[i];	
		}	
	}

	//we need to make sure the collision point is on our line
	if([p1 getDistanceFrom:p2] < [p1 getDistanceFrom:[Vect3d vectorWithX:cPoint[0] Y:cPoint[1] Z:cPoint[2]]])
		return NO;
	
	return YES;
}

BOOL vertexIsInCube(Vect3d *v, Vect3d *center, float width)
{
	return ([v getX] > ([center getX]-width/2) && [v getX] < ([center getX]+width/2)
			&& [v getY] > ([center getY]-width/2) && [v getY] < ([center getY]+width/2)
			&& [v getZ] > ([center getZ]-width/2) && [v getZ] < ([center getZ]+width/2));
}