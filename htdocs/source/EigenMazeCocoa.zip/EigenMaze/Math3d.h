/*
 *  Math3d.h
 *  EigenMaze
 *
 *  Created by Matthew Hielscher on 4/12/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include <math.h>

#import "Vect3d.h"
#import "Plane.h"

float getPlaneDistance(Vect3d *planeNormal, Vect3d *pointOnPlane);
float getPointDistanceFromPlane(Vect3d *planeNormal, float distance, Vect3d *point);
BOOL isPointInFrontOfPlane(Vect3d *planeNormal, float distance, Vect3d *point);
Vect3d *getCollisionPointWithPlane(Plane *plane, Vect3d *point, Vect3d *direction);
Vect3d *getCollisionPointWithPlaneDef(Vect3d *planeNormal, float distance, Vect3d *point, Vect3d direction);
BOOL lineIntersectsAABCube(Vect3d *cen, float radius, Vect3d *p1, Vect3d *p2);
BOOL vertexIsInCube(Vect3d *v, Vect3d *center, float width);