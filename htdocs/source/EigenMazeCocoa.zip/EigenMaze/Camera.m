//
//  Camera.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/14/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Camera.h"


@implementation Camera

- (id)init
{
	position = [[Vect3d alloc] init];
	lookAt = [[Vect3d alloc] init];
	frustum = [[Frustum alloc] init];
	return self;
}

- (void)setPositionTo:(Vect3d*)v
{
	position = v;
}

- (void)setLookAt:(Vect3d*)v
{
	[v retain];
	[lookAt release];
	lookAt = v;
}

- (Frustum*)getFrustum
{
	return frustum;
}

- (void)update
{
	gluLookAt([position getX], [position getY], [position getZ],
				[lookAt getX], [lookAt getY], [lookAt getZ],
				0, 1, 0);
	[frustum calculate];
}

- (void)dealloc
{
	[position release];
	[lookAt release];
	[frustum release];
	[super dealloc];
}

@end
