//
//  DisplayHandler.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/10/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "DisplayHandler.h"
#include <sys/time.h>

@implementation DisplayHandler

- (id)init
{
	displayableList = [[NSMutableSet setWithCapacity:10] retain];
	eigenCamera = [[Camera alloc] init];
	renderFrame = 0;
	frameCount = 0;
	gettimeofday(&lastTime, nil);
	return self;
}

- (void)update
{
	[self drawEntities];
}

- (void)add:(id <Drawable>)entity
{
	[displayableList addObject:entity];
}

- (void)drawEntities
{
	renderFrame++;
	frameCount++;
	struct timeval currentTime;
	gettimeofday(&currentTime, nil);
	long milliseconds = ((currentTime.tv_sec - lastTime.tv_sec)*1000 +
						(currentTime.tv_usec - lastTime.tv_usec)/1000);
	if (milliseconds >= 2000)
	{
		float fps = ((float)frameCount/milliseconds)*2000;
		NSLog(@"FPS: %f", fps);
		lastTime = currentTime;
		frameCount = 0;
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	[eigenCamera update];
	
	[displayableList makeObjectsPerformSelector:@selector(drawGL)];
}

- (void)setCameraWithX:(GLfloat)x Y:(GLfloat)y Z:(GLfloat)z
{
	[eigenCamera setPositionTo:[[[Vect3d alloc] initWithX:x Y:y Z:z] autorelease]];
}	

- (void)setCameraLookAtX:(GLfloat)x Y:(GLfloat)y Z:(GLfloat)z
{
	[eigenCamera setLookAt:[[[Vect3d alloc] initWithX:x Y:y Z:z] autorelease]];
}

- (long)getRenderFrame
{
	return renderFrame;
}

- (void)dealloc
{
	[displayableList release];
	[eigenCamera release];
	[super dealloc];
}

@end
