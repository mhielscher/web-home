//
//  RandomMaze.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/13/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "RandomMaze.h"


@implementation RandomMaze

- (id)initWithWidth:(int)w height:(int)h
{
	width = w;
	height = h;
	
	//allocate the maze
	maze = NSZoneCalloc(nil, width*height, sizeof(MazeCell));
	
	//init each cell to fully blocked
	MazeCell allBlocked = {BLOCKED, BLOCKED, BLOCKED, BLOCKED};
	for (int i=0; i<width; i++)
		for (int j=0; j<height; j++)
			maze[i*width+j] = allBlocked;
	
	srandom([[NSDate date] timeIntervalSince1970]);
	NSPoint point = {random()%width, random()%height};
	NSMutableArray *cellStack = [NSMutableArray arrayWithCapacity:width*height];
	
	[cellStack addObject:[NSValue valueWithPoint:point]];
	
	int cellCounter = width*height;
	while (cellCounter > 1)
	{
		MazeCell *currentCell = &maze[((int)point.x)*width+((int)point.y)];
		int direction = INVALID;
		int failCount = 0;
		NSPoint nextPoint = point;
		do
		{
			direction = random()%4;
			switch (direction)
			{
				case NORTH:
					nextPoint.y--;
					break;
				case EAST:
					nextPoint.x++;
					break;
				case SOUTH:
					nextPoint.y++;
					break;
				case WEST:
					nextPoint.x--;
					break;
			}
			//not a valid move if the cell doesn't exist, or it has already lost a wall
			if (nextPoint.x < 0 || nextPoint.x >= width || nextPoint.y < 0 || nextPoint.y >= height)
			{
				direction = INVALID;
				failCount++;
				continue;
			}
			MazeCell *nextCell = &maze[(int)(nextPoint.x*width+nextPoint.y)];
			if (!(nextCell->north && nextCell->south && nextCell->east && nextCell->west))
			{
				direction = INVALID;
				failCount++;
				continue;
			}
		} while (direction == INVALID && failCount < 3);
		if (direction == INVALID)
		{
			[cellStack removeLastObject];
			point = [[cellStack lastObject] pointValue];
		}
		else
		{
			switch (direction)
			{
				case NORTH:
					currentCell->north = OPEN;
					break;
				case EAST:
					currentCell->east = OPEN;
					break;
				case SOUTH:
					currentCell->south = OPEN;
					break;
				case WEST:
					currentCell->west = OPEN;
					break;
			}
			point = nextPoint;
			[cellStack addObject:[NSValue valueWithPoint:point]];
			cellCounter--;
		}
	}
	
	NSMutableArray *triangles = [NSMutableArray arrayWithCapacity:(width*height)*16]; //approx. 16 tris per cell max
	for (int x=0; x<width; x++)
	{
		for (int y=0; y<height; y++)
		{
			MazeCell *currentCell = &maze[x*width+y];
			float baseX = CELL_SIZE * x;
			float baseY = CELL_SIZE * y;

			Vect3d *v[13];
			v[0] = [Vect3d vectorWithX:baseX Y:baseY Z:0];
			v[1] = [Vect3d vectorWithX:baseX+CELL_SIZE Y:baseY Z:0];
			v[2] = [Vect3d vectorWithX:baseX Y:baseY+CELL_SIZE Z:0];
			v[3] = [Vect3d vectorWithX:baseX+CELL_SIZE Y:baseY+CELL_SIZE Z:0];
			v[4] = [Vect3d vectorWithX:baseX Y:baseY Z:WALL_HEIGHT];
			v[5] = [Vect3d vectorWithX:baseX+CELL_SIZE Y:baseY Z:WALL_HEIGHT];
			v[6] = [Vect3d vectorWithX:baseX Y:baseY+CELL_SIZE Z:WALL_HEIGHT];
			v[7] = [Vect3d vectorWithX:baseX+CELL_SIZE Y:baseY+CELL_SIZE Z:WALL_HEIGHT];
			v[8] = [Vect3d vectorWithX:baseX Y:baseY+CELL_SIZE+WALL_WIDTH Z:WALL_HEIGHT];
			v[9] = [Vect3d vectorWithX:baseX+CELL_SIZE Y:baseY+CELL_SIZE+WALL_WIDTH Z:WALL_HEIGHT];
			v[10] = [Vect3d vectorWithX:baseX+CELL_SIZE+WALL_WIDTH Y:baseY Z:WALL_HEIGHT];
			v[11] = [Vect3d vectorWithX:baseX+CELL_SIZE+WALL_WIDTH Y:baseY+CELL_SIZE Z:WALL_HEIGHT];
			v[12] = [Vect3d vectorWithX:baseX+CELL_SIZE+WALL_WIDTH Y:baseY+CELL_SIZE+WALL_WIDTH Z:WALL_HEIGHT];
			
			Triangle *t[16];
			t[0] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[6], v[2], nil] color:BEIGE] autorelease];
			t[1] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[4], v[6], nil] color:BEIGE] autorelease];
			t[2] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[1], v[5], nil] color:BEIGE] autorelease];
			t[3] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[4], v[5], nil] color:BEIGE] autorelease];
			t[4] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[3], v[1], nil] color:BEIGE] autorelease];
			t[5] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[0], v[2], v[3], nil] color:BEIGE] autorelease];
			t[6] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[9], v[11], v[12], nil] color:BEIGE] autorelease];
			t[7] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[7], v[9], v[11], nil] color:BEIGE] autorelease];
			t[8] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[5], v[3], v[7], nil] color:BEIGE] autorelease];
			t[9] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[5], v[3], v[1], nil] color:BEIGE] autorelease];
			t[10] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[6], v[3], v[7], nil] color:BEIGE] autorelease];
			t[11] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[6], v[3], v[2], nil] color:BEIGE] autorelease];
			t[12] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[6], v[8], v[9], nil] color:BEIGE] autorelease];
			t[13] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[6], v[7], v[9], nil] color:BEIGE] autorelease];
			t[14] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[5], v[10], v[11], nil] color:BEIGE] autorelease];
			t[15] = [[[Triangle alloc] initWithVertices:[NSArray arrayWithObjects:v[5], v[7], v[11], nil] color:BEIGE] autorelease];
			
			[triangles addObject:t[4]];
			[triangles addObject:t[5]];
			if (currentCell->north)
			{
				[triangles addObject:t[2]];
				[triangles addObject:t[3]];
			}
			if (currentCell->south)
			{
				[triangles addObject:t[10]];
				[triangles addObject:t[11]];
				[triangles addObject:t[12]];
				[triangles addObject:t[13]];
			}
			if (currentCell->east)
			{
				[triangles addObject:t[8]];
				[triangles addObject:t[9]];
				[triangles addObject:t[14]];
				[triangles addObject:t[15]];
			}
			if (currentCell->west)
			{
				[triangles addObject:t[0]];
				[triangles addObject:t[1]];
			}
			if (currentCell->south && currentCell->east) {
				[triangles addObject:t[6]];
				[triangles addObject:t[7]];
			}
		}
	}
	
	staticLevel = [[Octree alloc] initWithTriangles:triangles];
	
	return self;
}

- (int)getWidth
{
	return width;
}

- (int)getHeight
{
	return height;
}

@end