//
//  RandomMaze.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/13/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Drawable.h"
#import "Level.h"

#define WALL_WIDTH 2
#define WALL_HEIGHT 3
#define CELL_SIZE 16

enum {
	BLOCKED = NO,
	OPEN = YES,
	INVALID = -1,
	NORTH = 0,
	EAST,
	SOUTH,
	WEST
};

struct MazeCell {
	BOOL north, south, east, west;
};

typedef struct MazeCell MazeCell;

@interface RandomMaze : Level {
	int width, height;
	struct MazeCell *maze; // = NSZoneCalloc(nil, width*height, sizeof(MazeCell));
}

- (id)initWithWidth:(int)w height:(int)h;

- (int)getWidth;
- (int)getHeight;

@end
