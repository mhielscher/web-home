//
//  Octree.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Drawable.h"
#import "Frustum.h"
#import "OctreeNode.h"

@interface Octree : NSObject <Drawable> {
	NSMutableArray* triangles;
	Vect3d *center;
	float width;
	OctreeNode *root;
}

- (id)init;
- (id)initWithTriangles:(NSArray*)tri;

- (float)determineWidth;

- (void)drawGL;
- (void)drawGLWithFrustum:(Frustum*)frustum;

- (void)dealloc;

@end
