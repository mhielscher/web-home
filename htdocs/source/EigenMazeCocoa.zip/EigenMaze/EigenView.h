/* EigenView */

#import <Cocoa/Cocoa.h>
#import <OpenGL/OpenGL.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>

#import "EigenEngine.h"
#import "Entity.h"
#import "Constants.h"

@interface EigenView : NSOpenGLView
{
	BOOL isFullscreen;
	
	NSWindow *fullscreenWindow;
	NSWindow *startingWindow;
	NSTimer *time;
}

- (IBAction)toggleFullscreen:(id)sender;
- (id)initWithFrame:(NSRect)frameRect;
- (void)initGL;

@end
