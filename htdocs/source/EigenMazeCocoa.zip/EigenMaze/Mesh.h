//
//  Mesh.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/22/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "Vect3d.h"
#import "Triangle.h"
#import "Drawable.h"


@interface Mesh : NSObject <Drawable> {
	NSString *name;
	NSMutableArray *triangles;
	
	int displayListID;
	
	BOOL castShadow;
	BOOL hasNeighborsBeenSet;
	
	//ShadowVolume *shadowVolume;
}

- (id)init;
- (id)initWithName:(NSString*)n Triangles:(NSArray*)t;
- (id)initWithTriangles:(NSArray*)t;

- (NSString*)getName;
- (NSArray*)getTriangles;
- (void)setName:(NSString*)n;
- (void)setTriangles:(NSArray*)t;
- (NSArray*)translateWithX:(float)x Y:(float)y Z:(float)z;
- (void)generateDisplayList;
- (void)drawGL;
- (void)removeTrianglesWithNormal:(Vect3d*)norm;
- (void)drawShadowWithPosition:(Vect3d*)pos Rotation:(Vect3d*)rot Light:(int)l;
- (void)calculateTriangleNeighbors;

- (void)dealloc;

@end
