//
//  Triangle.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/3/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Triangle.h"
#import "EigenEngine.h"

@implementation Triangle

-(id)init
{
	vertices = [[NSMutableArray arrayWithCapacity:3] retain];
	uvPoints = nil;
	EigenColor c = { 1.0f, 1.0f, 1.0f };
	color = c;
	texture = nil;
	
	possibleEdgeCollision = 0;
	realCollisionPoint = nil;
	planeDistance = 0;
	
	lightmapEnabled = NO;
	[self setRenderOnce:NO];
	
	neighbors = [[NSMutableDictionary dictionaryWithCapacity:3] retain];
	
	return self;
}

-(id)initWithVertices:(NSArray*)vert color:(EigenColor)c
{
	vertices = [[NSMutableArray alloc] initWithArray:vert copyItems:YES];
	uvPoints = nil;
	color = c;
	texture = nil;
	
	[self calculateNormal];
	possibleEdgeCollision = 0;
	realCollisionPoint = nil;
	planeDistance = [self getPlaneDistance];
	
	lightmapEnabled = false;
	[self setRenderOnce:NO];
	
	neighbors = [[NSMutableDictionary dictionaryWithCapacity:3] retain];
	
	return self;
}

-(id)initWithVertices:(NSArray*)vert uv:(NSArray*)uv color:(EigenColor)c texture:(Texture*)tex
{
	vertices = [[NSMutableArray alloc] initWithArray:vert copyItems:YES];
	uvPoints = [[NSMutableArray alloc] initWithArray:uv copyItems:YES];
	color = c;
	texture = tex;
	
	[self calculateNormal];
	possibleEdgeCollision = 0;
	realCollisionPoint = nil;
	planeDistance = [self getPlaneDistance];
	
	lightmapEnabled = NO;
	[self setRenderOnce:NO];
	
	neighbors = [[NSMutableDictionary dictionaryWithCapacity:3] retain];
	
	return self;
}


+(void)calculateTriangleNeighbors:(NSArray*)triangles
{/*
	int num = [triangles length];
	Triangle *cur, *tmp;
	
	NSEnumerator *enumerator = [triangles objectEnumerator];
	while (cur = [enumerator nextObject])
	{
		for (int edge=0; edge<3; edge++)
		{
			if (![cur hasNeighborAtEdge:edge])
			{
				Vect3d *va1 = [cur getVertexNumber:edge];
				Vect3d *va2 = [cur getVertexNumber:((edge+1)%3)];
				NSEnumerator
			}
		}
	}*/
}


-(Vect3d*)getNormal
{
	return normal;
}

-(void)setNormal:(Vect3d*)v
{
	[v retain];
	[normal release];
	normal = v;
}

-(Vect3d*)getVertexNumber:(int)num
{
	num = num%3;
	return [vertices objectAtIndex:num];
}

-(void)setVertexNumber:(int)num vector:(Vect3d*)v
{
	num = num%3;
	[vertices replaceObjectAtIndex:num withObject:v];
}

-(NSPoint)getUVNumber:(int)num
{
	num = num%3;
	return [[uvPoints objectAtIndex:num] pointValue];
}

-(EigenColor)getColor
{
	return color;
}

-(void)setColor:(EigenColor)c
{
	color = c;
}

-(Texture*)getTexture
{
	return texture;
}

-(void)setTexture:(Texture*)tex
{
	[tex retain];
	[texture release];
	texture = tex;
}

-(void)setRenderOnce:(BOOL)b
{
	renderOnce = b;
}

-(BOOL)hasLightmap
{
	return lightmapEnabled;
}

-(void)setNeighbor:(Triangle*)neighbor edge:(int)edge
{
	[neighbors setObject:neighbor forKey:[NSNumber numberWithInt:edge]];
}

-(BOOL)hasNeighborAtEdge:(int)edge
{
	return ([neighbors objectForKey:[NSNumber numberWithInt:edge]] != nil);
}

-(Triangle*)getNeighborAtEdge:(int)edge
{
	return [neighbors objectForKey:[NSNumber numberWithInt:edge]];
}

-(void)setVisible:(BOOL)b
{
	visible = b;
}

-(BOOL)isVisible
{
	return visible;
}

-(void)calculateNormal
{
	Vect3d *a = [vertices objectAtIndex:0];
	Vect3d *b = [vertices objectAtIndex:0];
	Vect3d *c = [vertices objectAtIndex:0];
	
	normal = [[a subtractBy:b] crossWith:[a subtractBy:c]];
	normal = [[normal normalize] retain];
}

-(float)getPlaneDistance
{
	return -1.0f * [normal dotWith:[vertices objectAtIndex:0]];
}

-(void)createLightmap
{
	//maybe later?
}


//collision detection
-(enum SpherePosition)classifySphereWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel
{
	float distance = [self getDistanceFromPlaneToPoint:cen];
	Vect3d *predCen = [cen addWith:vel];
	float distance2 = [self getDistanceFromPlaneToPoint:predCen];
	
	if (abs(distance) <= radius || abs(distance2) <= radius)
		return INTERSECT;
	else if ((distance-radius > 0 && distance2-radius < 0) || (distance-radius < 0 && distance2-radius > 0))
		return INTERSECT;
	else if (distance2 > radius)
		return FRONT;
	else
		return BACK;
}

-(float)getDistanceFromPlaneToPoint:(Vect3d*)point
{
	return [normal dotWith:point] + planeDistance;
}

-(BOOL)pointInFront:(Vect3d*)point
{
	if ([self getDistanceFromPlaneToPoint:point] >= 0)
		return true;
	else
		return false;
}

-(BOOL)pointInTriangle:(Vect3d*)point
{
	// if this turns out to be slow, see bottom of NeHe Article 10
	float angle = 0;
	for (int i=0; i<3; i++)
	{
		angle += [[[vertices objectAtIndex:i] subtractBy:point] getAngleWith:
					[[vertices objectAtIndex:((i+1)%3)] subtractBy:point]];
	}
	return (angle >= (0.999*360));
}

-(BOOL)planeIntersectedByLineFrom:(Vect3d*)p1 to:(Vect3d*)p2
{
	float d1 = [self getDistanceFromPlaneToPoint:p1];
	float d2 = [self getDistanceFromPlaneToPoint:p2];
	
	return ((d1*d2) < 0);
}

-(BOOL)collisionPointInTriWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel
{
	/* This algorithm uses the formula:
				   D + A*P1x + B*P1y + C*P1z
		mu = ---------------------------------------
			 A*(P2x-P1x) + B*(P2y-P1y) + C*(P2z-P1z)
		to find the point on the move-line that intersects the plane of the triangle.
		Of course, we want to find the point at which the outer edge of the sphere
		intersects the triangle, so we move the plane forward by the radius (the
		sphere will always collide such that its radius is in the opposite direction
		to the normal of the triangle). Then we find where the move-line intersects
		this shifted plane, and that is the location of the center of the sphere when
		it collides with the plane. This position is then moved towards the triangle by
		the radius to make up for the previously "moved" plane. This is now the collision
		point, and we just make sure that it is within the triangle. */
	
	possibleEdgeCollision = 0;
	float D = planeDistance - radius;
	Vect3d *predCen = [cen addWith:vel];
	float denom = ([normal getX]*([cen getX]-[predCen getX]) + [normal getY]*([cen getY]-[predCen getY])
					+ [normal getZ]*([cen getZ]-[predCen getZ]));
	if (denom == 0) return false;
	float mu = (D + ([normal getX]*[cen getX]) + ([normal getY]*[cen getY]) + ([normal getZ]*[cen getZ]))/denom;
	if (mu >= 0 && mu <= 1)
	{
		Vect3d *position = [cen addWith:[[predCen subtractBy:cen] multiplyWith:mu]]; //check me on this...
		float distance = [self getDistanceFromPlaneToPoint:position];
		[position addWith:[normal multiplyWith:-radius]];
		if ([self pointInTriangle:position])
		{
			collisionPoint = distance;
			return true;
		}
		else
			possibleEdgeCollision = distance;
	}
	return false;
}

-(float)getMostRecentCollisionPoint
{
	return collisionPoint;
}

-(enum CollisionType)checkSphereCollisionWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel
{
	if ([vel length] == 0) return NONE;
	int classify = [self classifySphereWithCenter:cen radius:radius velocity:vel];
	if (classify == INTERSECT)
	{
		if ([self collisionPointInTriWithCenter:cen radius:radius velocity:vel])
			return DIRECT;
		else if ([self checkEdgeCollisionWithCenter:cen radius:radius velocity:vel])
			return EDGE;
	}
	return NONE;
}

-(Vect3d*)getRealCollisionPoint
{
	return realCollisionPoint;
}

-(BOOL)checkEdgeCollisionWithCenter:(Vect3d*)cen radius:(float)radius velocity:(Vect3d*)vel
{
	/* This algorithm calculates the shortest distance between the move-line
	   and the two vertical lines of the triangle. First it gets the vectors related
	   to the move-line and a triangle line, then it gets their mutual perpendicular
	   unit vector with a cross-product and by normalizing. Then it gets the vector
	   between two points on those lines - one point on the triangle, and the
	   current center point - and dots that with the unit perpendicular vector.
	   This results in the shortest distance between the two lines. If it is less
	   than the bounding sphere's radius, there is a collision. */
	return false;
}

-(BOOL)edgeContainsPoint:(Vect3d*)p
{
	float angle = 0;
	for (int i=0; i<3; i++)
	{
		angle = [[[vertices objectAtIndex:i] subtractBy:p] getAngleWith:
					[[vertices objectAtIndex:((i+1)%3)] subtractBy:p]];
		if (angle >= (0.999*180)) return true;
	}
	return false;
}


-(BOOL)isEqualTo:(id)object
{
	//apparently not used
	return NO;
}

-(NSComparisonResult)compareTo:(id)object
{
	if ([object getTexture] == texture)
		return NSOrderedSame;
	else if (texture == nil)
		return NSOrderedAscending;
	else if ([object getTexture] == nil)
		return NSOrderedDescending;
	else
		return NSOrderedSame; // return [texture compareTo:[object getTexture]];
}

-(void)drawGL
{
	if (renderOnce && renderFrame == [[[EigenEngine instance] getDisplay] getRenderFrame])
		return;
	renderFrame = [[[EigenEngine instance] getDisplay] getRenderFrame];
	
	if (texture == nil || uvPoints == nil)
		[self drawGLPlain];
	else if (lightmapEnabled)
	{
		glDisable(GL_LIGHTING);
		[self drawGLMultitexture];
		glEnable(GL_LIGHTING);
	}
	else
		[self drawGLTextured];
}

-(void)drawGLPlain
{
	Vect3d *vert;
	glBegin(GL_TRIANGLES);
	glNormal3f([normal getX], [normal getY], [normal getZ]);
	glColor3f(color.r, color.g, color.b);
	
	vert = [self getVertexNumber:0];
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	vert = [self getVertexNumber:1];
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	vert = [self getVertexNumber:2];
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	glEnd();
}

-(void)drawGLTextured
{
	NSPoint uv;
	Vect3d *vert;
	glEnable(GL_LIGHTING);
	//[[TextureManager instance] bindTexture:texture];
	glBegin(GL_TRIANGLES);
	glNormal3f([normal getX], [normal getY], [normal getZ]);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	uv = [self getUVNumber:0];
	vert = [self getVertexNumber:0];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:1];
	vert = [self getVertexNumber:1];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:2];
	vert = [self getVertexNumber:2];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	glEnd();
}

-(void)drawGLMultitexture
{
	NSPoint uv, uvl;
	Vect3d *vert;
	
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	//texture.bind(gldraw);
	//TextureManager.getInstance().bindTexture(texture);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	//glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_REPLACE);

	glActiveTextureARB(GL_TEXTURE1_ARB);
	glEnable(GL_TEXTURE_2D);
	//lightmap.bind();
	//texture.bind();
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	//glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_MULT);	

	glBegin(GL_TRIANGLES);
	
	uv = [self getUVNumber:0];
	uvl = [[uvLightmap objectAtIndex:0] pointValue];
	vert = [self getVertexNumber:0];
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, uv.x, uv.y);
	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, uvl.x, uvl.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:1];
	uvl = [[uvLightmap objectAtIndex:1] pointValue];
	vert = [self getVertexNumber:1];
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, uv.x, uv.y);
	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, uvl.x, uvl.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:2];
	uvl = [[uvLightmap objectAtIndex:2] pointValue];
	vert = [self getVertexNumber:2];
	glMultiTexCoord2fARB(GL_TEXTURE0_ARB, uv.x, uv.y);
	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, uvl.x, uvl.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	glEnd();

	glActiveTextureARB(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);

	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

-(void)drawGLRaw
{
	NSPoint uv;
	Vect3d *vert;
	
	glNormal3f([normal getX], [normal getY], [normal getZ]);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	uv = [self getUVNumber:0];
	vert = [self getVertexNumber:0];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:1];
	vert = [self getVertexNumber:1];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
	
	uv = [self getUVNumber:2];
	vert = [self getVertexNumber:2];
	glTexCoord2f(uv.x, uv.y);
	glVertex3f([vert getX], [vert getY], [vert getZ]);
}

-(void)dealloc
{
	[vertices release];
	[uvPoints release];
	if (texture)
		[texture release];
	[normal release];
	[realCollisionPoint release];
	[uvLightmap release];
	[super dealloc];
}

@end
