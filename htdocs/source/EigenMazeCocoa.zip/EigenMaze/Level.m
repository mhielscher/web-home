//
//  Level.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Level.h"


@implementation Level

- (id)init
{
	staticLevel = [[Octree alloc] init];
	return self;
}

- (void)drawGL
{
	[staticLevel drawGL];
}

- (void)drawGLWithFrustum:(Frustum*)frustum
{
	[staticLevel drawGLWithFrustum:frustum];
}

- (void)dealloc
{
	[staticLevel release];
	[super dealloc];
}

@end
