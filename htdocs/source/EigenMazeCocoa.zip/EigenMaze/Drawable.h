//
//  Drawable.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <OpenGL/OpenGL.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>

@protocol Drawable
- (void)drawGL;
@end
