//
//  Frustum.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <OpenGL/OpenGL.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>

#import "Plane.h"
#import "Vect3d.h"

@interface Frustum : NSObject {
	Plane *frustum[6];
}

- (id)init;
- (void)calculate;
- (BOOL)isCubeInFrustum:(Vect3d*)center size:(float)size;

- (void)dealloc;

@end
