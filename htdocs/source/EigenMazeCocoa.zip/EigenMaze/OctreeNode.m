//
//  OctreeNode.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/12/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "OctreeNode.h"
#import "Math3d.h"


@implementation OctreeNode

- (id)init
{
	parent = nil;
	children = nil;
	center = [[Vect3d alloc] init];
	width = 0;
	triangles = nil;
	planes = [[NSArray alloc] init];
	displayListID = -1;
	return self;
}

- (id)initWithCenter:(Vect3d*)cen width:(float)w
{
	parent = nil;
	children = nil;
	center = [cen retain];
	width = w;
	triangles = nil;
	planes = [[NSArray alloc] init];
	displayListID = -1;
	return self;
}

- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen
{
	parent = nil;
	children = nil;
	center = [cen retain];
	triangles = [tri sortedArrayUsingSelector:@selector(compareTo:)];
	planes = [[NSArray alloc] init];
	displayListID = -1;
	width = [self determineWidth];
	
	if ([triangles count] > MAXIMUM_LEAF_SIZE)
		[self buildChildren];
	
	return self;
}

- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen width:(float)w
{
	parent = nil;
	children = nil;
	center = [cen retain];
	triangles = [tri sortedArrayUsingSelector:@selector(compareTo:)];
	planes = [[NSArray alloc] init];
	displayListID = -1;
	width = w;
	
	if ([triangles count] > MAXIMUM_LEAF_SIZE)
		[self buildChildren];
	
	return self;
}

- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen parent:(OctreeNode*)p
{
	parent = [p retain];
	children = nil;
	center = [cen retain];
	triangles = [tri sortedArrayUsingSelector:@selector(compareTo:)];
	planes = [[NSArray alloc] init];
	displayListID = -1;
	width = [self determineWidth];
	
	if ([triangles count] > MAXIMUM_LEAF_SIZE)
		[self buildChildren];
	
	return self;
}

- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen width:(float)w parent:(OctreeNode*)p
{
	parent = [p retain];
	children = nil;
	center = [cen retain];
	triangles = [tri sortedArrayUsingSelector:@selector(compareTo:)];
	planes = [[NSArray alloc] init];
	displayListID = -1;
	width = w;
	
	if ([triangles count] > MAXIMUM_LEAF_SIZE)
		[self buildChildren];
	
	return self;
}

- (void)buildChildren
{
	/*
	Using a three-bit mask to generate cube segment tests for each vertex/triangle:
	+x, +y, +z = 000
	-x, -y, -z = 111
	*/
	children = [[NSMutableArray alloc] initWithCapacity:8];
	char mask = 0;
	float xMult = 0, yMult = 0, zMult = 0;
	for (mask=0; mask<8; ++mask)
	{
		xMult = (mask&0x1)*2 - 1;
		yMult = ((mask&0x2)>>1)*2 - 1;
		zMult = ((mask&0x4)>>2)*2 - 1;
		float nwidth = width/2; //width of each child
		Vect3d *ncenter = [center addWith:[Vect3d vectorWithX:nwidth/2 Y:nwidth/2 Z:nwidth/2]]; //child's center
		
		NSMutableArray *divTris = [NSMutableArray arrayWithCapacity:[triangles count]/8];
		
		// It should be noted that this does not catch all boundary cases - some triangles could be lost
		// See Graphics Gems III pg. 236 for additions
		// According to the above, we could be losing 13% or more
		NSEnumerator *enumerator = [triangles objectEnumerator];
		id tri;
		while (tri = [enumerator nextObject])
		{
			BOOL contained = NO;
			for (int i=0; i<3 && !contained; i++)
			{
				if (vertexIsInCube([tri getVertexNumber:i], ncenter, nwidth))
					contained = YES;
			}
			for (int i=0; i<3 && !contained; i++)
			{
				if (lineIntersectsAABCube(ncenter, nwidth/2, [tri getVertexNumber:i], [tri getVertexNumber:i+1]))
					contained = YES;
			}
			if (contained)
				[divTris addObject:tri];
		}
		
		if ([divTris count] > 0)
			[children addObject:[[OctreeNode alloc] initWithTriangles:[divTris retain] center:ncenter width:nwidth parent:self]];
		else
			[children addObject:[NSNull null]];
	}
	[triangles release];
	triangles = nil;
}

- (Vect3d*)getCenter
{
	return center;
}

- (float)getWidth
{
	return width;
}

- (float)determineWidth
{
	float maxWidth = 0;

	NSEnumerator *enumerator = [triangles objectEnumerator];
	Vect3d *point;
	id tri;
	while (tri = [enumerator nextObject])
	{
		for (int i=0; i<3; i++)
		{
			point = [tri getVertexNumber:i];
			if (abs([point getX]-[center getX]) > maxWidth)
				maxWidth = abs([point getX]-[center getX]);
			if (abs([point getY]-[center getY]) > maxWidth)
				maxWidth = abs([point getY]-[center getY]);
			if (abs([point getZ]-[center getZ]) > maxWidth)
				maxWidth = abs([point getZ]-[center getZ]);
		}
	}
	return maxWidth;
}

- (BOOL)nodeContainsSphereWithCenter:(Vect3d*)cen radius:(float)r
{
	float hw = width/2;
	return (([center getX]-hw-r) <= [cen getX] && ([center getX]+hw+r) >= [cen getX]
			&& ([center getY]-hw-r) <= [cen getY] && ([center getY]+hw+r) >= [cen getY]
			&& ([center getZ]-hw-r) <= [cen getZ] && ([center getZ]+hw+r) >= [cen getZ]);
}

- (BOOL)nodeIntersectedByLineFrom:(Vect3d*)p1 to:(Vect3d*)p2
{
	return lineIntersectsAABCube(center, width/2, p1, p2);
}

- (BOOL)blocksLineFrom:(Vect3d*)p1 to:(Vect3d*)p2
{
	if (![self nodeIntersectedByLineFrom:p1 to:p2])
		return NO;
	
	NSEnumerator *enumerator = [triangles objectEnumerator];
	id tri;
	while (tri = [enumerator nextObject])
	{
		if ([tri planeIntersectedByLineFrom:p1 to:p2]) return YES;
	}
	
	return NO;
}

- (BOOL)containsVertex:(Vect3d*)v
{
	return ([v getX] > ([center getX]-width/2) && [v getX] < ([center getX]+width/2)
			&& [v getY] > ([center getY]-width/2) && [v getY] < ([center getY]+width/2)
			&& [v getZ] > ([center getZ]-width/2) && [v getZ] < ([center getZ]+width/2));
}

- (void)generateDisplayList
{
	displayListID = glGenLists(1);
	glNewList(displayListID, GL_COMPILE);
	//[[TextureManager getInstance] bindTexture:[[triangles objectAtIndex:0] getTexture]];
	glBegin(GL_TRIANGLES);
	[triangles makeObjectsPerformSelector:@selector(drawGLRaw)];
	glEnd();
	glEndList();
}

- (void)drawTrisGL
{
	[triangles makeObjectsPerformSelector:@selector(drawGL)];
}

- (void)drawGL
{
	if (!triangles)
	{
		NSEnumerator *enumerator = [children objectEnumerator];
		id child;
		while (child = [enumerator nextObject])
		{
			if (child == [NSNull null]) continue;
			[child drawGL];
		}
	}
	else
		[self drawTrisGL];
}

- (void)drawGLWithFrustum:(Frustum*)frustum
{
	if ([frustum isCubeInFrustum:center size:width])
		[self drawGL];
}

- (void)dealloc
{
	//assume parent released us, and leave him alone; he'll dealloc himself
	if (children)
	{
		NSEnumerator *enumerator = [children objectEnumerator];
		id child;
		while (child = [enumerator nextObject])
		{
			if (child == [NSNull null]) continue;
			[child release];
		}
	}
	[center release];
	[triangles release];
	[planes release];
	
	[super dealloc];
}

@end
