//
//  Vect3d.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Vect3d.h"


@implementation Vect3d

+ (id)unitVectorX
{
	return [[[Vect3d alloc] initWithX:1 Y:0 Z:0] autorelease];
}

+ (id)unitVectorY
{
	return [[[Vect3d alloc] initWithX:0 Y:1 Z:0] autorelease];
}

+ (id)unitVectorZ
{
	return [[[Vect3d alloc] initWithX:0 Y:0 Z:1] autorelease];
}

+ (id)vectorWithX:(float)u Y:(float)v Z:(float)w
{
	return [[[Vect3d alloc] initWithX:u Y:v Z:w] autorelease];
}

- (id)init
{
	x = 0;
	y = 0;
	z = 0;
	return self;
}


- (id)initWithX:(float)u Y:(float)v Z:(float)w
{
	x = u;
	y = v;
	z = w;
	return self;
}

- (float)getX
{
	return x;
}

- (float)getY
{
	return y;
}

- (float)getZ
{
	return z;
}

- (void)setToX:(float)u Y:(float)v Z:(float)w
{
	x = u;
	y = v;
	z = w;
}

- (void)setX:(float)u
{
	x = u;
}

- (void)setY:(float)v
{
	y = v;
}

- (void)setZ:(float)w
{
	z = w;
}

- (Vect3d*)invert
{
	return [[[Vect3d alloc] initWithX:x*-1 Y:y*-1 Z:z*-1] autorelease];
}

- (float)length
{
	return (float)sqrtf((x*x)+(y*y)+(z*z));
}

- (Vect3d*)normalize
{
	float len = [self length];
	if (len != 0) {
		float u = x / len;
		float v = y / len;
		float w = z / len;
		return [[[Vect3d alloc] initWithX:u Y:v Z:w] autorelease];
	}
	return [[[Vect3d alloc] initWithX:x Y:y Z:z] autorelease];
}

- (float)dotWith:(Vect3d*)vec
{
	float u = x * vec->x;
	float v = y * vec->y;
	float w = z * vec->y;
	return u + v + w;
}

- (Vect3d*)crossWith:(Vect3d*)vec
{
	float u = (y * vec->z) - (z * vec->y);
	float v = (z * vec->x) - (x * vec->z);
	float w = (x * vec->y) - (y * vec->x);
	return [[[Vect3d alloc] initWithX:u Y:v Z:w] autorelease];
}

- (float)getAngleWith:(Vect3d*)vec
{
	float f = acosf([self dotWith:vec] / ([self length]*[vec length]));
	return f * 180.0f/M_PI;
}

- (Vect3d*)multiplyWith:(float)scalar
{
	return [[[Vect3d alloc] initWithX:x*scalar Y:y*scalar Z:z*scalar] autorelease];
}

- (Vect3d*)divideBy:(float)scalar
{
	return [[[Vect3d alloc] initWithX:x/scalar Y:y/scalar Z:z/scalar] autorelease];
}

- (Vect3d*)subtractBy:(Vect3d*)vec
{
	float u = x - vec->x;
	float v = y - vec->y;
	float w = z - vec->z;
	return [[[Vect3d alloc] initWithX:u Y:v Z:w] autorelease];
}

- (Vect3d*)addWith:(Vect3d*)vec
{
	float u = x + vec->x;
	float v = y + vec->y;
	float w = z + vec->z;
	return [[[Vect3d alloc] initWithX:u Y:v Z:w] autorelease];
}

- (Vect3d*)rotateY:(float)angle
{
	angle /= (180.0f/M_PI);
	float u = z * sinf(angle) + x * cosf(angle);
	float w = z * cosf(angle) + x * sinf(angle);
	return [[[Vect3d alloc] initWithX:u Y:y Z:w] autorelease];
}

- (BOOL)isEqual:(id)object
{

	if ([object isMemberOfClass:[Vect3d class]])
	{
		Vect3d *vec = (Vect3d*)object;
		return (x == vec->x && y == vec->y && z == vec->z);
	}

	return NO;
}

- (float)getDistanceFrom:(Vect3d*)point
{
	return [[self subtractBy:point] length];
}

- (id)copyWithZone:(NSZone*)zone
{
	return [[Vect3d allocWithZone:zone] initWithX:x Y:y Z:z];
}

- (void)dealloc
{
	[super dealloc];
}

@end
