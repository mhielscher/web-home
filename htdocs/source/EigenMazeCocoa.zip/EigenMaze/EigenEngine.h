//
//  EigenEngine.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/10/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Drawable.h"
#import "DisplayHandler.h"

@interface EigenEngine : NSObject { //singleton
	DisplayHandler *eigenDisplay;
}

+ (EigenEngine*)instance;
- (id)init;
- (void)update;
- (void)add:(id <Drawable>)entity;
- (DisplayHandler*)getDisplay;

- (void)dealloc;

@end

static EigenEngine *theEngine = nil;