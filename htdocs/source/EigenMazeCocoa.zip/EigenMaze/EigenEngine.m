//
//  EigenEngine.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/10/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "EigenEngine.h"


@implementation EigenEngine

+ (EigenEngine*)instance
{
	if (theEngine == nil)
		theEngine = [[EigenEngine alloc] init];
	return theEngine;
}

- (id)init
{
	if (![super init])
		return nil;
	eigenDisplay = [[DisplayHandler alloc] init];
	return self;
}

- (void)update
{
	[eigenDisplay update];
}

- (void)add:(id <Drawable>)entity
{
	if (entity != nil)
		[eigenDisplay add:entity];
}

- (DisplayHandler*)getDisplay
{
	return eigenDisplay;
}

- (void)dealloc
{
	[eigenDisplay release];
	theEngine = nil;
	[super dealloc];
}

@end
