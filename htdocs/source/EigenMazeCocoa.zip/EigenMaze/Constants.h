//
//  Constants.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#define BITS_PER_PIXEL 32.0
#define DEPTH_SIZE 32.0
#define DEFAULT_TIME_INTERVAL 0.001
#define DEFAULT_FOV 45.0f