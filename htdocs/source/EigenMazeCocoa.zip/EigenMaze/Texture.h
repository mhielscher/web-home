//
//  Texture.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/3/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Texture : NSObject {

}

@end
