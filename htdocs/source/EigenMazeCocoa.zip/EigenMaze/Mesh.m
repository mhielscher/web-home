//
//  Mesh.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/22/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Mesh.h"


@implementation Mesh

- (id)init
{
	name = @"unnamed";
	triangles = nil;
	displayListID = -1;
	hasNeighborsBeenSet = NO;
	castShadow = NO;
	return self;
}

- (id)initWithName:(NSString*)n Triangles:(NSArray*)t
{
	name = [[NSString stringWithString:n] retain];
	triangles = [[NSMutableArray arrayWithArray:t] retain];
	[triangles sortUsingSelector:@selector(compareWith:)];
	displayListID = -1;
	hasNeighborsBeenSet = NO;
	castShadow = NO;
	return self;
}

- (id)initWithTriangles:(NSArray*)t
{
	name = @"unnamed";
	triangles = [[NSMutableArray arrayWithArray:t] retain];
	[triangles sortUsingSelector:@selector(compareWith:)];
	displayListID = -1;
	hasNeighborsBeenSet = NO;
	castShadow = NO;
	return self;
}

- (NSString*)getName
{
	return name;
}

- (NSArray*)getTriangles
{
	return [NSArray arrayWithArray:triangles];
}

- (void)setName:(NSString*)n
{
	[name autorelease];
	name = [[NSString stringWithString:n] retain];
}

- (void)setTriangles:(NSArray*)t
{
	[triangles autorelease];
	triangles = [[NSMutableArray arrayWithArray:t] retain];
	[triangles sortUsingSelector:@selector(compareWith:)];
	displayListID = -1;
}

- (NSArray*)translateWithX:(float)x Y:(float)y Z:(float)z
{
	NSArray *newTri = [[[NSArray alloc] initWithArray:triangles copyItems:YES] autorelease];
	[newTri makeObjectsPerformSelector:@selector(translateWithVect:) withObject:[[[Vect3d alloc] initWithX:x Y:y Z:z] autorelease]];
	return newTri;
}

- (void)generateDisplayList
{
	displayListID = glGenLists(1);
	glNewList(displayListID, GL_COMPILE);
	//TextureManager.getInstance().unbindTexture();
	[triangles makeObjectsPerformSelector:@selector(drawGL)];
	glEndList();
}

- (void)drawGL
{
	[triangles makeObjectsPerformSelector:@selector(drawGL)];
}

- (void)removeTrianglesWithNormal:(Vect3d*)norm
{
	NSMutableArray *toBeRemoved = [NSMutableArray array];
	NSEnumerator *enumerator = [triangles objectEnumerator];
	id aTriangle;
	while (aTriangle = [enumerator nextObject])
	{
		if ([[aTriangle getNormal] isEqualTo:norm])
			[toBeRemoved addObject:aTriangle];
	}
	[triangles removeObjectsInArray:toBeRemoved];
}

- (void)drawShadowWithPosition:(Vect3d*)pos Rotation:(Vect3d*)rot Light:(int)l
{
	//not yet
}

- (void)calculateTriangleNeighbors
{
	if (!hasNeighborsBeenSet)
		[Triangle calculateTriangleNeighbors:triangles];
	hasNeighborsBeenSet = YES;
}

- (void)dealloc
{
	[name release];
	[triangles release];
	[super dealloc];
}

@end
