//
//  OctreeNode.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 4/12/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Drawable.h"
#import "Vect3d.h"
#import "Triangle.h"
#import "Frustum.h"

#define MAXIMUM_LEAF_SIZE 200

@interface OctreeNode : NSObject {
	OctreeNode *parent;
	NSMutableArray *children;
	
	Vect3d *center;
	float width;
	NSArray *triangles;
	NSArray *planes;
	
	int displayListID;
}

- (id)init;
- (id)initWithCenter:(Vect3d*)cen width:(float)w;
- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen;
- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen width:(float)w;
- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen parent:(OctreeNode*)p;
- (id)initWithTriangles:(NSArray*)tri center:(Vect3d*)cen width:(float)w parent:(OctreeNode*)p;

- (void)buildChildren;

- (Vect3d*)getCenter;
- (float)getWidth;

- (float)determineWidth;

- (BOOL)nodeContainsSphereWithCenter:(Vect3d*)cen radius:(float)r;
- (BOOL)nodeIntersectedByLineFrom:(Vect3d*)p1 to:(Vect3d*)p2;
- (BOOL)blocksLineFrom:(Vect3d*)p1 to:(Vect3d*)p2;
- (BOOL)containsVertex:(Vect3d*)v;

- (void)generateDisplayList;
- (void)drawTrisGL;
- (void)drawGL;
- (void)drawGLWithFrustum:(Frustum*)frustum;

- (void)dealloc;

@end
