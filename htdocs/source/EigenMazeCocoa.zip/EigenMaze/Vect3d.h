//
//  Vect3d.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include <math.h>


@interface Vect3d : NSObject <NSCopying> {
	float x, y, z;
}

+ (id)unitVectorX;
+ (id)unitVectorY;
+ (id)unitVectorZ;

+ (id)vectorWithX:(float)u Y:(float)v Z:(float)w;

- (id)init;
- (id)initWithX:(float)u Y:(float)v Z:(float)w;

- (float)getX;
- (float)getY;
- (float)getZ;
- (void)setToX:(float)u Y:(float)v Z:(float)w;
- (void)setX:(float)x;
- (void)setY:(float)y;
- (void)setZ:(float)z;
- (Vect3d*)invert;
- (float)length;
- (Vect3d*)normalize;
- (float)dotWith:(Vect3d*)vec;
- (Vect3d*)crossWith:(Vect3d*)vec;
- (float)getAngleWith:(Vect3d*)vec;
- (Vect3d*)multiplyWith:(float)scalar;
- (Vect3d*)divideBy:(float)scalar;
- (Vect3d*)subtractBy:(Vect3d*)vec;
- (Vect3d*)addWith:(Vect3d*)vec;
- (Vect3d*)rotateY:(float)angle;
- (BOOL)isEqual:(id)object;
- (float)getDistanceFrom:(Vect3d*)point;

- (id)copyWithZone:(NSZone*)zone;

- (void)dealloc;

@end
