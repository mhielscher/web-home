//
//  Plane.m
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "Plane.h"


@implementation Plane

- (id)init;
{
	normal = [[Vect3d alloc] init];
	distance = 0;
	return self;
}

- (id)initWithA:(float)a B:(float)b C:(float)c D:(float)d;
{
	normal = [[Vect3d alloc] init];
	[self setA:a B:b C:c D:d];
	return self;
}

- (id)initWithNormal:(Vect3d*)n distance:(float)d;
{
	[n retain];
	normal = n;
	distance = d;
	return self;
}

- (id)initWithNormal:(Vect3d*)n point:(Vect3d*)p;
{
	[n retain];
	normal = n;
	distance = -1.0f * [normal dotWith:p];
	return self;
}

- (void)setA:(float)a B:(float)b C:(float)c D:(float)d;
{
	[normal setToX:a Y:b Z:c];
	distance = d;
}

- (float)getPlaneDistance;
{
	return distance;
}

- (Vect3d*)getNormal;
{
	return normal;
}

- (float)getPointDistance:(Vect3d*)p;
{
	return [normal dotWith:p] + distance;
}

- (void)normalize;
{
	float len = [normal length];
	if (len != 0)
	{
		[normal autorelease];
		normal = [[normal normalize] retain];
		distance /= len;
	}
}

- (BOOL)isPointInFront:(Vect3d*)p;
{
	return (([normal dotWith:p]+distance) >= 0);
}

- (BOOL)isPointInFrontX:(float)x Y:(float)y Z:(float)z;
{
	return [self isPointInFront:[[[Vect3d alloc] initWithX:x Y:y Z:z] autorelease]];
}

- (BOOL)doesLineIntersectFrom:(Vect3d*)p1 to:(Vect3d*)p2;
{
	return YES; //never implemented or used?
}

- (void)dealloc
{
	[normal release];
	[super dealloc];
}

@end
