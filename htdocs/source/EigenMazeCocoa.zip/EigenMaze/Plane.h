//
//  Plane.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "Vect3d.h"

@interface Plane : NSObject {
	Vect3d *normal;
	float distance;
}

- (id)init;
- (id)initWithA:(float)a B:(float)b C:(float)c D:(float)d;
- (id)initWithNormal:(Vect3d*)n distance:(float)distance;
- (id)initWithNormal:(Vect3d*)n point:(Vect3d*)p;

- (void)setA:(float)a B:(float)b C:(float)c D:(float)d;
- (float)getPlaneDistance;
- (Vect3d*)getNormal;
- (float)getPointDistance:(Vect3d*)p;
- (void)normalize;
- (BOOL)isPointInFront:(Vect3d*)p;
- (BOOL)isPointInFrontX:(float)x Y:(float)y Z:(float)z;
- (BOOL)doesLineIntersectFrom:(Vect3d*)p1 to:(Vect3d*)p2;

- (void)dealloc;

@end
