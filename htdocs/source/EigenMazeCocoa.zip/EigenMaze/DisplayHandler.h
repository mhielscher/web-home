//
//  DisplayHandler.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/10/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "Drawable.h"
#import "Camera.h"


@interface DisplayHandler : NSObject {
	NSMutableSet *displayableList;
	Camera *eigenCamera;
	
	GLfloat camCordX, camCordY, camCordZ;
	GLfloat targetCordX, targetCordY, targetCordZ;
	
	long renderFrame, frameCount;
	struct timeval lastTime;
}

- (id)init;

- (void)update;
- (void)add:(id <Drawable>)entity;
- (void)drawEntities;
- (void)setCameraWithX:(GLfloat)x Y:(GLfloat)y Z:(GLfloat)z;
- (void)setCameraLookAtX:(GLfloat)x Y:(GLfloat)y Z:(GLfloat)z;
- (long)getRenderFrame;

- (void)dealloc;

@end
