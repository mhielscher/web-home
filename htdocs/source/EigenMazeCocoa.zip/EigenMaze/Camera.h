//
//  Camera.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/14/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <OpenGL/OpenGL.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>

#import "Frustum.h"
#import "Vect3d.h"

@interface Camera : NSObject {
	Vect3d *position;
	Vect3d *lookAt;
	Frustum *frustum;
}

- (id)init;
- (void)setPositionTo:(Vect3d*)v;
- (void)setLookAt:(Vect3d*)v;
- (Frustum*)getFrustum;
- (void)update;

- (void)dealloc;

@end
