#import "EigenView.h"

@implementation EigenView

- (IBAction)toggleFullscreen:(id)sender
{
	if (isFullscreen)
	{
		[fullscreenWindow close];
		[startingWindow setContentView:self];
		[startingWindow makeKeyAndOrderFront:self];
		[startingWindow makeFirstResponder:self];
		isFullscreen = false;
	}
	else
	{
		startingWindow = [NSApp keyWindow];
		
		unsigned int windowStyle = NSBorderlessWindowMask;
		NSRect contentRect = [[NSScreen mainScreen] frame];
		fullscreenWindow = [[NSWindow alloc] initWithContentRect:contentRect styleMask:windowStyle
												backing:NSBackingStoreBuffered defer:NO];
		
		if (fullscreenWindow != nil)
		{
			[fullscreenWindow setTitle:@"EigenMaze Fullscreen"];
			[fullscreenWindow setReleasedWhenClosed:YES];
			[fullscreenWindow setContentView:self];
			[fullscreenWindow makeKeyAndOrderFront:self];
			[fullscreenWindow setLevel:NSScreenSaverWindowLevel-1];
			[fullscreenWindow makeFirstResponder:self];
			isFullscreen = true;
		}
	}
}

- (id)initWithFrame:(NSRect)frameRect
{
	NSOpenGLPixelFormat *nsglFormat;
	NSOpenGLPixelFormatAttribute attr[] =
		{
			NSOpenGLPFADoubleBuffer,
			NSOpenGLPFAAccelerated,
			NSOpenGLPFAColorSize, BITS_PER_PIXEL,
			NSOpenGLPFADepthSize, DEPTH_SIZE,
			0
		};
	
	[self setPostsFrameChangedNotifications:YES]; //we want to know if the window size changes
	
	nsglFormat = [[NSOpenGLPixelFormat alloc] initWithAttributes:attr];
	if (!nsglFormat)
	{
		NSLog(@"Invalid NSGL format... terminating.");
		return nil;
	}
	self = [super initWithFrame:frameRect pixelFormat:nsglFormat];
	[nsglFormat release];
	if (!self)
	{
		NSLog(@"Self not created... terminating.");
		return nil;
	}
	
	[[self openGLContext] makeCurrentContext];
	[self initGL];
	
	NSArray *verts = [NSArray arrayWithObjects:[[Vect3d alloc] initWithX:0 Y:0 Z:0],
												[[Vect3d alloc] initWithX:0 Y:1 Z:1],
												[[Vect3d alloc] initWithX:1 Y:1 Z:0], nil];
	EigenColor c = {1,1,1};
	NSMutableArray *tris = [NSMutableArray arrayWithObject:[[Triangle alloc] initWithVertices:verts color:c]];
	Mesh *m = [[Mesh alloc] initWithTriangles:tris];
	Entity *object = [[[Entity alloc] init] autorelease];
	[object setMesh:m];
	[object setPosition:[[[Vect3d alloc] initWithX:0 Y:0 Z:-6] autorelease]];
	[object setVelocity:[[[Vect3d alloc] initWithX:.2 Y:-.3 Z:0] autorelease]];
	[[EigenEngine instance] add:object];
	[[[EigenEngine instance] getDisplay] setCameraLookAtX:0 Y:0 Z:-6];
	
	return self;
}

- (void)initGL
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
}

- (void)awakeFromNib
{
	time = [[NSTimer scheduledTimerWithTimeInterval:DEFAULT_TIME_INTERVAL
						target:self selector:@selector(drawFrame)
						userInfo:nil repeats:YES] retain];
	[[NSRunLoop currentRunLoop] addTimer:time forMode:NSEventTrackingRunLoopMode];
	[[NSRunLoop currentRunLoop] addTimer:time forMode:NSModalPanelRunLoopMode];
}

- (void)reshape
{
	float aspect;
	NSSize bound = [self frame].size;
	aspect = bound.width/bound.height;
	
	glViewport(0, 0, bound.width, bound.height);
	glMatrixMode(GL_PROJECTION);
	
	glLoadIdentity();
	gluPerspective(DEFAULT_FOV, (GLfloat)aspect, 0.1f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

- (void)drawFrame
{
	[[EigenEngine instance] update];

	[[self openGLContext] flushBuffer];
}

- (BOOL)acceptsFirstResponder
{
	return YES;
}

- (BOOL)becomeFirstResponder
{
	return YES;
}

@end
