//
//  Entity.h
//  EigenMaze
//
//  Created by Matthew Hielscher on 3/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Drawable.h"
#import "Vect3d.h"
#import "Mesh.h"


@interface Entity : NSObject <Drawable> {
	Mesh *mesh;
	Vect3d *position;
	Vect3d *velocity;
	Vect3d *forwardVect;
	Vect3d *rotation;
	float boundingRadius;
}

- (id)init;
- (void)setPosition:(Vect3d*)v;
- (void)setVelocity:(Vect3d*)v;
- (void)setMesh:(Mesh*)m;
- (void)setRotY:(float)y;
- (void)setRotZ:(float)z;
- (Vect3d*)getForwardVect;
- (Vect3d*)getPosition;
- (void)setBoundingRadius:(float)r;
- (void)drawGL;
- (void)update;

- (void)dealloc;

@end
